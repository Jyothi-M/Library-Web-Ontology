package RDF;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Writer;
import java.util.ArrayList;

import org.apache.jena.rdf.model.Model;
import org.apache.jena.rdf.model.ModelFactory;
import org.apache.jena.rdf.model.Property;
import org.apache.jena.rdf.model.Resource;
public class Library {
	private static final String FILE_PATH = "/Users/mavillajyothi/Desktop/WSProject.csv";
	private ArrayList<String>dataList, Books, Department, BookTransaction, Student, BookAuthor;
	public static void main(String[] args) {
		Library obj = new Library();
		obj.ReadData();
		obj.DataToRDF();
	
	}


		private void ReadData() {
			int i = 0;
			dataList = new ArrayList<>();
			Books = new ArrayList<>();
			Department = new ArrayList<>();
			BookTransaction = new ArrayList<>();
			Student = new ArrayList<>();
			BookAuthor = new ArrayList<>();
			File file = new File(FILE_PATH);
			if(file.exists()) {
				try {
				FileReader filereader = new FileReader(file);
				BufferedReader bufferreader = new BufferedReader(filereader);
				String read = "";
				while((read = bufferreader.readLine())!=null) {
					dataList.add(read);
						String temp[] = dataList.get(i).split(",");
						for(int j=0;j<temp.length;j++) {
							if(j==0) {
							    BookTransaction.add(temp[j]);
							}
							if(j==1) {
								Books.add(temp[j]);
							}
							if(j==2) {
								BookAuthor.add(temp[j]);
							}
							if(j==3) {
								Department.add(temp[j]);
							}
							if(j==4) {
								Student.add(temp[j]);
							}
						}
					
					i++;
				}
				
				}
				catch(IOException io) {
					io.printStackTrace();
				}
			}
			
			else {
				System.out.println("File is missing");
			}
		}
		
		private void DataToRDF() {
			Model mymodel = ModelFactory.createDefaultModel();
			Property Book = mymodel.createProperty("http://ex.org/property/BookName");         
			Property author =  mymodel.createProperty("http://ex.org/property/author");   
			Property studentName = mymodel.createProperty("http://ex.org/property/studentName");
			Property dept = mymodel.createProperty("http://ex.org/property/dept");
			for(int i = 1;i<dataList.size();i++) {
	                    Resource BookTransID = mymodel.createResource("http://ex.org/property/"+BookTransaction.get(i));
	                    BookTransID.addProperty(Book, Books.get(i));
	                    BookTransID.addProperty(author, BookAuthor.get(i));
	                    BookTransID.addProperty(dept, Department.get(i));
	                    BookTransID.addProperty(studentName, Student.get(i));
				
			}
			mymodel.write(System.out, "TURTLE");
			try {
				Writer wr = new FileWriter("/Users/mavillajyothi/Desktop/Data/library.ttl");
				mymodel.write(wr,"TURTLE");}
			catch(Exception e) {
				e.printStackTrace();
			}
		}
	}


